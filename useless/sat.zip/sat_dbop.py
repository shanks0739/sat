#!/usr/bin/env python3  
#coding=utf-8
# -*- coding:utf-8 -*-  


"""
golbal var
"""  
debug = False
#debug = True
import time
import datetime
import csv

import sat_util
import sat_thread
import sat_rtprice

r = sat_rtprice.r

cursor = sat_rtprice.cursor
errMysql = sat_rtprice.errMysql

codesfile = "util/A8.csv"
platefile = "util/plate.csv"


######################################################################
"""
thread op, public func
"""
def SavePrice2DBOnceByThread(func, codes):
    if (debug): print('SavePrice2DBOnceByThread', len(codes))
    n = len(codes)
    workNum = 100
    step = 20
    if (n < step):
        workNum = 1
    elif (n < 2000):
        workNum = (n / step) + 1
    else:
        workNum = 100

    start = 0
    t = sat_thread.SAT_Threads(workNum, 1)
    while True and start <= n:
        splitcodes=codes[start: start+step]
        t.add_job(func, splitcodes)
        start += step
    t.wait_allcomplete()
    if (debug): print('end...' ' n= ', n, 'start = ', start)


def SaveAllPrice2DBOnceByThreads(func):
    codes=sat_util.GetAllCodesFromCSV()
    if (debug): print('SaveAllPrice2DBOnceByThreads', len(codes))
    SavePrice2DBOnceByThread(func, codes)

#def MarketRunFlag():
    
#循环调用
def Day2Redis():
    codes = sat_util.GetAllCodesFromCSV()
    h=int(time.strftime("%H"))
    m=int(time.strftime("%M"))
    #使用时间来调用
    while True:
        while True and ((h == 9 and m >= 15) or (h>9 and h < 11) or (h == 11 and m <= 35) or (h >=13 and h<15) or (h == 15 and m <= 5) or (h == 17 and m <= 31)):
            SavePrice2DBOnceByThread(SaveMultiPrice2Redis, codes)
            h=int(time.strftime("%H"))
            m=int(time.strftime("%M"))
            if (debug): print('again get')
        time.sleep(1) #30s check 
        print("not start")
        if ((h == 15 and m > 5) or (h > 15) or (h < 9): 
            if (debug): print("program exit")
            break

#######################################################################

"""
operate reids 
"""
def InsertName2Redis():
    c = csv.reader(open(codesfile, encoding='utf8'))
    for id, code, name in c:
        if code != 'NULL' and len(code) >= 6:
            #name=sat_util.ToGB(name)
            r.set(code[:6]+'name', str(name))
            if (debug): print(code[:6], type(name), name)


def InsertPlate2Redis():
    p = csv.reader(open(platefile, encoding='utf16'))
    plates={}
    for plate, code, name in p:
        #insert redis
        r.lpush(plate, code)
        plates[plate]=name
        #print(name)
    for i in plates:
        r.lpush(i,plates[i])
        if (debug): print(i,plates[i])

def SaveSinglePrice2Redis(code):
    b,rp = sat_rtprice.GetPrice(code)
    if b: 
        rp.AllW2Redis()
        if (debug) : rp.PricePrint()
    if (debug): print("end or failed", b)

#以下这种方式非常慢，已经不采用
def SaveAllPrice2RedisOnce():
    codes=sat_util.GetAllCodesFromCSV()
    if (debug): print(len(codes))
    for i in range(0, len(codes)):
        SaveSinglePrice2Redis(codes[i])
    

def SaveMultiPrice2Redis(codes):
    lrp = sat_rtprice.GetPriceMulti(codes)
    for i in range(0, len(lrp)):
        lrp[i].AllW2Redis()
        if (debug): lrp[i].PricePrint()
    if (debug): print(len(lrp), ' end')

def SaveAllPrice2RedisOnceByThreads():
    SaveAllPrice2DBOnceByThreads(SaveMultiPrice2Redis)


"""
operate mysql
"""
def SaveSinglePrice2Mysql(code):
    b, rp = sat_rtprice.GetPrice(code)
    if b:
        rp.AllW2Mysql()
        if (debug): rp.PricePrint()

#这种方式非常慢
def SaveAllPrice2MysqlOnce():
    codes=sat_util.GetAllCodesFromCSV()
    for i in range(0, len(codes)):
        SaveSinglePrice2Mysql(codes[i])
    if (debug): print(len(codes))

lrpMysql=[]
def SaveMultiPrice2Mysql(codes):
    lrp = sat_rtprice.GetPriceMulti(codes)
#for i in range(0, len(lrp)):
#    lrp[i].AllW2Mysql()
#if (debug): lrp[i].PricePrint()
#
    for i in range(0, len(lrp)):
        lrpMysql.append(lrp[i])
    #lrpMysql.extend(lrp)

def SaveAllPrice2MysqlOnceByThreads():
    SaveAllPrice2DBOnceByThreads(SaveMultiPrice2Mysql)
    for i in range(0, len(lrpMysql)):
        lrpMysql[i].AllW2Mysql()
    
    
"""
csv file
"""
def SaveAllCodePriceOnceToCSV():
    f = open('RealTimePrice.csv', 'w', encoding='utf8')
    codes=sat_util.GetAllCodesFromCSV()
    for i in range(0, len(codes)):
        b, rp = sat_rtprice.GetPrice(code)
        if b:
            #rp.PricePrint()
            rp.WriteFile2CSV()
    f.close()

"""
sat_rtprice test csv,mysql,redis start 
"""

if __name__ == '__main__':
    start = time.time()
    #InsertName2Redis()
    #SaveAllPrice2MysqlOnce()
    #SaveAllPrice2MysqlOnceByThreads()
    #SaveAllPrice2RedisOnceByThreads()
    Day2Redis()
    
    end = time.time()
    print("total s %d" %(end - start))
